v0.1.2 show --last / --tail + append stdin hint
