# Changelog

## v0.1.1

Purpose: tool

- Added explicit append content sources: positional content, `--stdin`,
  and `--file <PATH>`.
- Added explicit append target selection with `--id <ID>` while keeping
  legacy positional strand IDs for positional content.
- Added conflict checks for content sources and target sources.
- Reject empty append content after whitespace-only detection while
  preserving leading whitespace in stored content.
- Rewrote `tasktree append --help` around invocation forms, content
  source, target, rules, and examples.
- Added diagnostic `tasktree --version` output with journal schema, git
  commit, and build profile.
- Added CLI help and branch policy contribution guidance.

## v0.1.0

Initial Windows reference implementation for the strand protocol.
