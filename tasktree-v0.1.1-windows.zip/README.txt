tasktree v0.1.1 — Windows

A cognitive external memory tool for AI agents.
Protocol: strand, append, [open].

Usage:
  tasktree init
  tasktree add "new topic"
  tasktree list
  tasktree show <id>
  tasktree append "thought"
  echo "long thought" | tasktree append --stdin
  tasktree append --file note.md --id <id>

Full protocol: https://github.com/GodOnlyKn0w/strand-protocol
