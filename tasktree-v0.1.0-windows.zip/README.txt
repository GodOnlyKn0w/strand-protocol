tasktree v0.1.0 — Windows

A cognitive external memory tool for AI agents.
Protocol: strand, append, [open].

Usage:
  tasktree init
  tasktree add "new topic"
  tasktree list
  tasktree show <id>
  tasktree append "thought"

Full protocol: https://github.com/GodOnlyKn0w/strand-protocol
